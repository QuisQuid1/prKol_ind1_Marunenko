﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.LinkLabel;

namespace WindowsFormsApp5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Queue<Person> people = new Queue<Person>();
            string file = "people.txt";
            string[] lines = File.ReadAllLines(file);
            if (File.Exists(file))
            {
                foreach (string files in lines)
                {
                    string[] parts=files.Split(' ');
                    Person person = new Person
                    {
                        LastName = parts[0],
                        FirstName = parts[1],
                        MiddleName = parts[2],
                        Age = int.Parse(parts[3]),
                        Pol = parts[4],
                        Zp = int.Parse(parts[5]),
                    };
                    people.Enqueue(person);
                }
                var zp = from zpm in people
                         where zpm.Zp < 10000
                         select zpm;
                var zp1 = from zpb in people
                         where zpb.Zp >= 10000
                         select zpb;
                foreach (var z in zp)
                {
                        listBox1.Items.Add($"ФИО: {z.LastName} {z.FirstName} {z.MiddleName}, Возраст: {z.Age}, Пол: {z.Pol}, Зарплата: {z.Zp}");
                }
                foreach (var z1 in zp1)
                {
                    listBox1.Items.Add($"ФИО: {z1.LastName} {z1.FirstName} {z1.MiddleName}, Возраст: {z1.Age}, Пол: {z1.Pol}, Зарплата: {z1.Zp}");
                }
                button1.Enabled = false;
            }
            else { MessageBox.Show("Файл не найден"); }
        }
       
    }
}
